
function checkUserLogin() {
    const userProfile = document.getElementById('userProfile');
    const userName = document.getElementById('userName');
    const data = localStorage.getItem('shahn_user');

    if (data && userProfile) {
        const user = JSON.parse(data);
        userProfile.style.display = 'flex';
        userName.innerText = user.name;
    }
}

function logout() {
    localStorage.removeItem('shahn_user');
    window.location.reload();
}
