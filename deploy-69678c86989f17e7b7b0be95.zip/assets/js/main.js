// مصفوفة البيانات الافتراضية للتشغيل الأول
const initialDB = {
    products: [
        { id: 1, name: "هاتف ذكي حديث", priceSAR: 1500, category: 1, img: "https://via.placeholder.com/300", description: "وصف المنتج هنا..." },
        { id: 2, name: "قميص قطني", priceSAR: 100, category: 2, img: "https://via.placeholder.com/300", description: "وصف المنتج هنا..." }
    ],
    categories: [
        { id: 1, name: "إلكترونيات", icon: "fa-mobile-alt" },
        { id: 2, name: "ملابس", icon: "fa-tshirt" }
    ],
    settings: {
        exchangeRate: 440, // سعر الصرف من سعودي لـ يمني
        deliveryFee: 20,
        whatsappNumber: "+967770000000"
    },
    offers: [
        { id: 1, title: "عروض الشتاء", subtitle: "خصم يصل إلى 50%", active: true, img: "https://via.placeholder.com/1200x500" }
    ],
    orders: []
};

// وظيفة الحصول على البيانات من المتصفح
function getDB() {
    const data = localStorage.getItem('shahn_db');
    if (!data) {
        // إذا كانت أول مرة، يتم تخزين البيانات الافتراضية
        localStorage.setItem('shahn_db', JSON.stringify(initialDB));
        return initialDB;
    }
    return JSON.parse(data);
}

// وظيفة حفظ التعديلات في المتصفح
function saveDB(db) {
    localStorage.setItem('shahn_db', JSON.stringify(db));
}

// وظيفة فارغة لتعطيل محاولات الاتصال بـ Supabase في الصفحات الأخرى
async function syncWithSupabase() {
    console.log("التطبيق يعمل بنظام التخزين المحلي السحابي (LocalStorage)");
    return true;
}